import FirebaseCore
import SwiftUI

@main
struct InstagramClone2010App: App {
    @StateObject private var store = PostStore()
    @StateObject private var instagramAuth = InstagramAuthManager()

    init() {
        // Only configure Firebase if a real GoogleService-Info.plist is present.
        // Without this guard, FirebaseApp.configure() crashes the app on launch
        // if you haven't set up Firebase yet — this lets everything else
        // (feed, filters, seed data, Instagram login/read) work standalone.
        if Bundle.main.path(forResource: "GoogleService-Info", ofType: "plist") != nil {
            FirebaseApp.configure()
        } else {
            print("⚠️ No GoogleService-Info.plist found — skipping Firebase setup. Posting to real Instagram will be unavailable until it's added (see README).")
        }
    }

    var body: some Scene {
        WindowGroup {
            RootTabView()
                .environmentObject(store)
                .environmentObject(instagramAuth)
                .onOpenURL { url in
                    // The redirect page forwards here via the custom scheme
                    // registered in Info.plist; ASWebAuthenticationSession
                    // also intercepts it directly, so this is just a safety net.
                    _ = url
                }
        }
    }
}
