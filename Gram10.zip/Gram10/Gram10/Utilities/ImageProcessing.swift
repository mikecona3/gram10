import UIKit
import CoreImage

enum ImageProcessing {
    private static let context = CIContext()

    /// Crops to a centered square — the original app only ever posted squares.
    static func squareCropped(_ image: UIImage) -> UIImage {
        let size = min(image.size.width, image.size.height)
        let origin = CGPoint(
            x: (image.size.width - size) / 2,
            y: (image.size.height - size) / 2
        )
        guard let cgImage = image.cgImage else { return image }

        let scale = CGFloat(cgImage.width) / image.size.width
        let cropRect = CGRect(
            x: origin.x * scale, y: origin.y * scale,
            width: size * scale, height: size * scale
        )
        guard let cropped = cgImage.cropping(to: cropRect) else { return image }
        return UIImage(cgImage: cropped, scale: image.scale, orientation: image.imageOrientation)
    }

    /// Applies a filter and returns a flattened UIImage, ready to store/display.
    static func filtered(_ image: UIImage, with filter: FilterType) -> UIImage {
        guard let ciImage = CIImage(image: image) else { return image }
        let output = filter.apply(to: ciImage)
        guard let cgImage = context.createCGImage(output, from: ciImage.extent) else { return image }
        return UIImage(cgImage: cgImage, scale: image.scale, orientation: image.imageOrientation)
    }

    /// Downloads a remote image (e.g. an Instagram media_url) into a UIImage.
    static func download(_ url: URL) async throws -> UIImage {
        let (data, _) = try await URLSession.shared.data(from: url)
        guard let image = UIImage(data: data) else {
            throw URLError(.cannotDecodeContentData)
        }
        return image
    }
}
