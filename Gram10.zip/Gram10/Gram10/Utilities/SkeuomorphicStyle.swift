import SwiftUI

/// Shared textures for the 2010-era "real materials" look: stitched leather,
/// brushed/wood grain, glossy buttons, aged photo borders.
enum Skeuo {
    // MARK: - Palette

    static let leatherDark = Color(red: 0.29, green: 0.17, blue: 0.09)
    static let leatherLight = Color(red: 0.46, green: 0.28, blue: 0.15)
    static let stitchCream = Color(red: 0.93, green: 0.85, blue: 0.68)
    static let woodDark = Color(red: 0.36, green: 0.22, blue: 0.11)
    static let woodLight = Color(red: 0.55, green: 0.36, blue: 0.19)
    static let paper = Color(red: 0.98, green: 0.97, blue: 0.93)
    static let chrome = Color(red: 0.78, green: 0.78, blue: 0.8)

    // MARK: - Instagram (2010) chrome: glossy blue nav bar, dark glossy tab bar

    static let instagramNavTop = Color(red: 0.58, green: 0.70, blue: 0.82)
    static let instagramNavBottom = Color(red: 0.18, green: 0.30, blue: 0.46)
    static let instagramTabTop = Color(red: 0.22, green: 0.22, blue: 0.24)
    static let instagramTabBottom = Color(red: 0.04, green: 0.04, blue: 0.05)
    static let instagramBlue = Color(red: 0.30, green: 0.53, blue: 0.82)
    static let instagramIconDim = Color.white.opacity(0.85)
}

// MARK: - Leather background with a subtle grain and diagonal sheen

struct LeatherBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Skeuo.leatherLight, Skeuo.leatherDark],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            Canvas { context, size in
                // Fine diagonal grain lines
                var rng = SeededGenerator(seed: 7)
                for _ in 0..<140 {
                    let x = CGFloat.random(in: 0...size.width, using: &rng)
                    let y = CGFloat.random(in: 0...size.height, using: &rng)
                    let len = CGFloat.random(in: 3...9, using: &rng)
                    var path = Path()
                    path.move(to: CGPoint(x: x, y: y))
                    path.addLine(to: CGPoint(x: x + len, y: y + len * 0.4))
                    context.stroke(path, with: .color(.black.opacity(0.06)), lineWidth: 0.6)
                }
            }
            LinearGradient(
                colors: [.white.opacity(0.12), .clear, .black.opacity(0.15)],
                startPoint: .top, endPoint: .bottom
            )
        }
    }
}

// MARK: - Wood grain background (tab bar)

struct WoodBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Skeuo.woodLight, Skeuo.woodDark],
                startPoint: .top, endPoint: .bottom
            )
            Canvas { context, size in
                var rng = SeededGenerator(seed: 3)
                var y: CGFloat = 0
                while y < size.height {
                    var path = Path()
                    path.move(to: CGPoint(x: 0, y: y))
                    path.addCurve(
                        to: CGPoint(x: size.width, y: y + CGFloat.random(in: -3...3, using: &rng)),
                        control1: CGPoint(x: size.width * 0.33, y: y + CGFloat.random(in: -4...4, using: &rng)),
                        control2: CGPoint(x: size.width * 0.66, y: y + CGFloat.random(in: -4...4, using: &rng))
                    )
                    context.stroke(path, with: .color(.black.opacity(0.10)), lineWidth: 0.8)
                    y += CGFloat.random(in: 4...8, using: &rng)
                }
            }
            LinearGradient(colors: [.white.opacity(0.08), .clear], startPoint: .top, endPoint: .bottom)
        }
    }
}

/// Deterministic RNG so the grain doesn't redraw differently every frame.
struct SeededGenerator: RandomNumberGenerator {
    private var state: UInt64
    init(seed: UInt64) { state = seed &+ 0x9E3779B97F4A7C15 }
    mutating func next() -> UInt64 {
        state ^= state << 13; state ^= state >> 7; state ^= state << 17
        return state
    }
}

// MARK: - Cream stitching border, like leather-bound apps of the era

struct StitchedBorder: ViewModifier {
    var cornerRadius: CGFloat = 10
    func body(content: Content) -> some View {
        content
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .strokeBorder(style: StrokeStyle(lineWidth: 1.5, dash: [4, 3]))
                    .foregroundStyle(Skeuo.stitchCream.opacity(0.8))
                    .padding(4)
            )
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .stroke(Color.black.opacity(0.35), lineWidth: 1)
            )
    }
}

extension View {
    func stitchedBorder(cornerRadius: CGFloat = 10) -> some View {
        modifier(StitchedBorder(cornerRadius: cornerRadius))
    }
}

// MARK: - Glossy chrome/plastic button, like the original circular shutter

struct GlossyButtonStyle: ButtonStyle {
    var tint: Color = Skeuo.chrome

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(
                ZStack {
                    Circle().fill(
                        RadialGradient(
                            colors: [tint.opacity(0.95), tint.opacity(0.6)],
                            center: .center, startRadius: 2, endRadius: 60
                        )
                    )
                    Circle()
                        .trim(from: 0, to: 0.5)
                        .fill(LinearGradient(colors: [.white.opacity(0.55), .clear], startPoint: .top, endPoint: .bottom))
                        .rotationEffect(.degrees(180))
                    Circle().strokeBorder(Color.black.opacity(0.4), lineWidth: 2)
                }
            )
            .scaleEffect(configuration.isPressed ? 0.93 : 1)
            .shadow(color: .black.opacity(0.5), radius: configuration.isPressed ? 2 : 6, y: configuration.isPressed ? 1 : 3)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

// MARK: - Aged Polaroid-style photo frame for feed posts

struct PolaroidFrame: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(6)
            .background(Skeuo.paper)
            .overlay(RoundedRectangle(cornerRadius: 2).stroke(.black.opacity(0.08), lineWidth: 1))
            .shadow(color: .black.opacity(0.35), radius: 5, x: 0, y: 3)
    }
}

extension View {
    func polaroidFrame() -> some View {
        modifier(PolaroidFrame())
    }
}

// MARK: - Weathered edge + vignette directly on feed photos (no polaroid margin)

struct VintagePhotoBorder: ViewModifier {
    func body(content: Content) -> some View {
        content
            .overlay(RadialGradient(colors: [.clear, .black.opacity(0.32)], center: .center, startRadius: 130, endRadius: 210))
            .overlay(RoundedRectangle(cornerRadius: 1).strokeBorder(Color.white.opacity(0.85), lineWidth: 3))
            .clipped()
    }
}

extension View {
    func vintagePhotoBorder() -> some View {
        modifier(VintagePhotoBorder())
    }
}

// MARK: - Fully custom Instagram (2010) chrome bars.
//
// These are hand-drawn SwiftUI views rather than UINavigationBar/UITabBar
// appearance hacks: on modern OS releases the system renders bars with
// Liquid Glass and actively resists opaque custom fills/tints, which
// muddles the flat glossy-blue/near-black look this app is going for.
// Drawing our own bars sidesteps that entirely.

struct InstagramNavBar<Trailing: View>: View {
    var title: String
    @ViewBuilder var trailing: () -> Trailing

    var body: some View {
        ZStack {
            // Centered independently of the trailing content's width, so the
            // title lands dead-center whether or not a tab has a trailing icon.
            Text(title)
                .font(.wordmark(28))
                .foregroundStyle(.white)
                .shadow(color: .black.opacity(0.5), radius: 0, x: 0, y: 1)
                .frame(maxWidth: .infinity, alignment: .center)

            HStack {
                Spacer()
                trailing()
            }
        }
        .padding(.horizontal, 12)
        .frame(height: 44)
        .frame(maxWidth: .infinity)
        .background(
            ZStack {
                LinearGradient(colors: [Skeuo.instagramNavTop, Skeuo.instagramNavBottom], startPoint: .top, endPoint: .bottom)
                LinearGradient(colors: [.white.opacity(0.22), .clear], startPoint: .top, endPoint: .center)
            }
            .ignoresSafeArea(edges: .top)
        )
        .overlay(alignment: .bottom) {
            Rectangle().fill(Color.black.opacity(0.55)).frame(height: 1)
        }
    }
}

extension InstagramNavBar where Trailing == EmptyView {
    init(title: String) {
        self.title = title
        self.trailing = { EmptyView() }
    }
}

struct InstagramTabBar<Tab: Hashable>: View {
    struct Item {
        let tab: Tab
        let icon: String
        var iconSize: CGFloat = 22
        /// The camera/share tab isn't really a "selected" destination in the
        /// original app — it always wears its own blue badge, whether or not
        /// it's the active tab.
        var isAction: Bool = false
    }

    @Binding var selection: Tab
    let items: [Item]

    var body: some View {
        HStack(spacing: 0) {
            ForEach(items, id: \.tab) { item in
                Button {
                    selection = item.tab
                } label: {
                    Group {
                        if item.isAction {
                            Image(systemName: item.icon)
                                .font(.system(size: item.iconSize * 0.8))
                                .foregroundStyle(.white)
                                .frame(width: item.iconSize * 1.7, height: item.iconSize * 1.25)
                                .background(RoundedRectangle(cornerRadius: 6).fill(Skeuo.instagramBlue))
                        } else {
                            Image(systemName: item.icon)
                                .font(.system(size: item.iconSize))
                                .foregroundStyle(selection == item.tab ? Skeuo.instagramBlue : Skeuo.instagramIconDim)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 10)
        .background(
            ZStack {
                LinearGradient(colors: [Skeuo.instagramTabTop, Skeuo.instagramTabBottom], startPoint: .top, endPoint: .bottom)
                LinearGradient(colors: [.white.opacity(0.14), .clear], startPoint: .top, endPoint: UnitPoint(x: 0.5, y: 0.1))
            }
            .ignoresSafeArea(edges: .bottom)
        )
        .overlay(alignment: .top) {
            Rectangle().fill(Color.white.opacity(0.14)).frame(height: 1)
        }
    }
}

// MARK: - The little camera badge that stands in for the app's icon/logo mark

struct VintageCameraBadge: View {
    var size: CGFloat = 30

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.22)
                .fill(LinearGradient(colors: [Skeuo.chrome, Color(white: 0.4)], startPoint: .top, endPoint: .bottom))
                .frame(width: size, height: size * 0.78)
            RoundedRectangle(cornerRadius: size * 0.22)
                .strokeBorder(Color.black.opacity(0.5), lineWidth: 1)
                .frame(width: size, height: size * 0.78)
            // viewfinder bump
            RoundedRectangle(cornerRadius: 2)
                .fill(Color(white: 0.35))
                .frame(width: size * 0.28, height: size * 0.16)
                .offset(y: -size * 0.44)
            // lens
            Circle()
                .fill(RadialGradient(colors: [.white.opacity(0.8), Skeuo.woodDark, .black], center: .center, startRadius: 0, endRadius: size * 0.25))
                .frame(width: size * 0.5, height: size * 0.5)
            Circle()
                .stroke(Color.black.opacity(0.6), lineWidth: 1.5)
                .frame(width: size * 0.5, height: size * 0.5)
            // shutter button
            Circle()
                .fill(Color.red.opacity(0.85))
                .frame(width: size * 0.12, height: size * 0.12)
                .offset(x: size * 0.32, y: -size * 0.32)
        }
    }
}

// MARK: - Script-style wordmark font (falls back gracefully if unavailable)

extension Font {
    /// Matches the original hand-lettered script logotype as closely as a
    /// system-available font allows. Snell Roundhand ships on iOS; falls
    /// back to a system serif-italic if it's ever missing.
    static func wordmark(_ size: CGFloat) -> Font {
        if UIFont(name: "SnellRoundhand-Bold", size: size) != nil {
            return .custom("SnellRoundhand-Bold", size: size, relativeTo: .largeTitle)
        }
        return .system(size: size, weight: .bold, design: .serif).italic()
    }
}
