import UIKit

enum SeedData {
    private struct SeedPost {
        let username: String
        let caption: String
        let symbol: String
        let colors: [UIColor]
        let filter: FilterType
        let hoursAgo: Double
    }

    private static let seeds: [SeedPost] = [
        SeedPost(username: "mara_travels", caption: "Golden hour on the coast 🌅",
                  symbol: "sun.max.fill", colors: [UIColor(red: 1, green: 0.6, blue: 0.3, alpha: 1), UIColor(red: 0.9, green: 0.3, blue: 0.4, alpha: 1)],
                  filter: .earlybird, hoursAgo: 2),
        SeedPost(username: "jcoffeeco", caption: "Sunday morning ritual",
                  symbol: "cup.and.saucer.fill", colors: [UIColor(red: 0.45, green: 0.3, blue: 0.2, alpha: 1), UIColor(red: 0.2, green: 0.13, blue: 0.08, alpha: 1)],
                  filter: .xProII, hoursAgo: 5),
        SeedPost(username: "finn.and.pup", caption: "Best hiking buddy there is 🐾",
                  symbol: "pawprint.fill", colors: [UIColor(red: 0.5, green: 0.6, blue: 0.4, alpha: 1), UIColor(red: 0.25, green: 0.32, blue: 0.2, alpha: 1)],
                  filter: .hefe, hoursAgo: 9),
        SeedPost(username: "citylights_nyc", caption: "Nights like this",
                  symbol: "building.2.fill", colors: [UIColor(red: 0.1, green: 0.1, blue: 0.2, alpha: 1), UIColor(red: 0.3, green: 0.2, blue: 0.5, alpha: 1)],
                  filter: .sutro, hoursAgo: 15),
        SeedPost(username: "plated_by_sam", caption: "Homemade pasta night",
                  symbol: "fork.knife", colors: [UIColor(red: 0.85, green: 0.75, blue: 0.5, alpha: 1), UIColor(red: 0.6, green: 0.35, blue: 0.2, alpha: 1)],
                  filter: .loFi, hoursAgo: 22),
        SeedPost(username: "wanderlust_kai", caption: "Found this little trail today",
                  symbol: "leaf.fill", colors: [UIColor(red: 0.3, green: 0.5, blue: 0.3, alpha: 1), UIColor(red: 0.15, green: 0.3, blue: 0.18, alpha: 1)],
                  filter: .toaster, hoursAgo: 30),
    ]

    /// Only seeds when the store is empty, so it never overwrites real posts
    /// (yours or imported) on later launches.
    static func populateIfEmpty(_ store: PostStore) {
        guard store.posts.isEmpty else { return }
        for seed in seeds {
            let art = renderPlaceholder(symbol: seed.symbol, colors: seed.colors)
            let finished = ImageProcessing.filtered(art, with: seed.filter)
            store.addPost(
                image: finished,
                filter: seed.filter,
                caption: seed.caption,
                username: seed.username,
                createdAt: Date().addingTimeInterval(-seed.hoursAgo * 3600)
            )
        }
    }

    /// Draws a simple gradient-plus-icon square — stands in for a stock photo
    /// without pulling in any actual licensed imagery.
    private static func renderPlaceholder(symbol: String, colors: [UIColor], size: CGFloat = 640) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: size, height: size))
        return renderer.image { ctx in
            let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors.map(\.cgColor) as CFArray, locations: [0, 1])!
            ctx.cgContext.drawLinearGradient(gradient, start: .zero, end: CGPoint(x: size, y: size), options: [])

            let config = UIImage.SymbolConfiguration(pointSize: size * 0.32, weight: .regular)
            if let icon = UIImage(systemName: symbol, withConfiguration: config)?.withTintColor(.white.withAlphaComponent(0.85), renderingMode: .alwaysOriginal) {
                let iconSize = icon.size
                let origin = CGPoint(x: (size - iconSize.width) / 2, y: (size - iconSize.height) / 2)
                icon.draw(at: origin)
            }
        }
    }
}
