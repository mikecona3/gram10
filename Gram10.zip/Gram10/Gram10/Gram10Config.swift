import Foundation

/// Fill these in after registering your app at developers.facebook.com
/// and adding the Instagram product (see README for the full walkthrough).
enum InstagramConfig {
    /// App Dashboard > Instagram > API setup with Instagram login > Instagram App ID
    static let appID = "YOUR_INSTAGRAM_APP_ID"

    /// App Dashboard > Instagram > API setup with Instagram login > Instagram App Secret
    /// ⚠️ See the security note in README — shipping a secret inside a client app
    /// is fine for a personal/dev build but not for anything you'd distribute.
    static let appSecret = "YOUR_INSTAGRAM_APP_SECRET"

    /// The https redirect page you host (see README) — must exactly match what
    /// you entered in the App Dashboard's "Business login settings".
    static let redirectURI = "https://your-username.github.io/ig-redirect/"

    /// The custom URL scheme your redirect page forwards into, and that this
    /// app registers in Info.plist (see README).
    static let callbackScheme = "instaclone2010"

    static let scope = "instagram_business_basic,instagram_business_content_publish"
}
