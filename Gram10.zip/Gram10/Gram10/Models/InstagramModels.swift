import Foundation

struct IGShortLivedToken: Decodable {
    let access_token: String
    let user_id: String
}

struct IGLongLivedToken: Decodable {
    let access_token: String
    let token_type: String
    let expires_in: Int
}

struct IGProfile: Decodable {
    let id: String
    let username: String
    let account_type: String?
}

struct IGMediaResponse: Decodable {
    let data: [IGMediaItem]
}

struct IGMediaItem: Decodable, Identifiable {
    let id: String
    let caption: String?
    let media_type: String   // IMAGE, VIDEO, CAROUSEL_ALBUM
    let media_url: String?
    let timestamp: String
    let permalink: String?
}

struct IGContainerCreated: Decodable {
    let id: String
}

struct IGContainerStatus: Decodable {
    let status_code: String   // EXPIRED, ERROR, FINISHED, IN_PROGRESS, PUBLISHED
}

struct IGPublishedMedia: Decodable {
    let id: String
}
