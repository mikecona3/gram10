import SwiftUI

struct Post: Identifiable {
    let id = UUID()
    let username: String
    let image: UIImage      // already square-cropped + filtered
    let filter: FilterType
    var caption: String
    let createdAt: Date

    var timeAgo: String {
        let seconds = Int(Date().timeIntervalSince(createdAt))
        switch seconds {
        case ..<60: return "\(max(seconds, 1))s"
        case ..<3600: return "\(seconds / 60)m"
        case ..<86400: return "\(seconds / 3600)h"
        default: return "\(seconds / 86400)d"
        }
    }
}
