import CoreImage
import CoreImage.CIFilterBuiltins

/// Recreations of the original 2010 filter pack, built from stock CoreImage filters.
enum FilterType: String, CaseIterable, Identifiable {
    case normal = "Normal"
    case xProII = "X-Pro II"
    case loFi = "Lo-Fi"
    case earlybird = "Earlybird"
    case hefe = "Hefe"
    case sutro = "Sutro"
    case toaster = "Toaster"

    var id: String { rawValue }

    /// Applies the filter's look to an input CIImage.
    func apply(to input: CIImage) -> CIImage {
        var image = input

        switch self {
        case .normal:
            break

        case .xProII:
            // Punchy contrast + saturation, warm vignette, cool-shadow tint.
            image = colorControls(image, saturation: 1.3, brightness: 0.02, contrast: 1.15)
            image = tone(image, warm: 0.08, tint: -0.04)
            image = vignette(image, intensity: 1.2, radius: 1.8)

        case .loFi:
            // Heavy contrast + saturation, warm shadows — the "moody desert" look.
            image = colorControls(image, saturation: 1.5, brightness: -0.02, contrast: 1.35)
            image = vignette(image, intensity: 0.9, radius: 2.0)

        case .earlybird:
            // Sepia base with a soft warm haze and vignette.
            image = sepia(image, intensity: 0.55)
            image = colorControls(image, saturation: 1.1, brightness: 0.05, contrast: 0.95)
            image = vignette(image, intensity: 0.8, radius: 1.6)

        case .hefe:
            // High contrast, slightly cooled highlights, saturated.
            image = colorControls(image, saturation: 1.25, brightness: 0.0, contrast: 1.2)
            image = tone(image, warm: -0.03, tint: 0.0)
            image = vignette(image, intensity: 0.7, radius: 2.0)

        case .sutro:
            // Dark, desaturated, heavy vignette — burnt corners.
            image = colorControls(image, saturation: 0.85, brightness: -0.08, contrast: 1.1)
            image = vignette(image, intensity: 1.6, radius: 1.3)

        case .toaster:
            // Warm, glowing center, strong vignette, boosted contrast.
            image = colorControls(image, saturation: 1.2, brightness: 0.04, contrast: 1.3)
            image = tone(image, warm: 0.12, tint: -0.02)
            image = vignette(image, intensity: 1.8, radius: 1.4)
        }

        return image
    }

    // MARK: - Filter building blocks

    private func colorControls(_ image: CIImage, saturation: Double, brightness: Double, contrast: Double) -> CIImage {
        let filter = CIFilter.colorControls()
        filter.inputImage = image
        filter.saturation = Float(saturation)
        filter.brightness = Float(brightness)
        filter.contrast = Float(contrast)
        return filter.outputImage ?? image
    }

    private func sepia(_ image: CIImage, intensity: Double) -> CIImage {
        let filter = CIFilter.sepiaTone()
        filter.inputImage = image
        filter.intensity = Float(intensity)
        return filter.outputImage ?? image
    }

    private func tone(_ image: CIImage, warm: Double, tint: Double) -> CIImage {
        let filter = CIFilter.temperatureAndTint()
        filter.inputImage = image
        filter.neutral = CIVector(x: 6500 + CGFloat(warm * 2000), y: CGFloat(tint * 200))
        filter.targetNeutral = CIVector(x: 6500, y: 0)
        return filter.outputImage ?? image
    }

    private func vignette(_ image: CIImage, intensity: Double, radius: Double) -> CIImage {
        let filter = CIFilter.vignette()
        filter.inputImage = image
        filter.intensity = Float(intensity)
        filter.radius = Float(radius)
        return filter.outputImage ?? image
    }
}
