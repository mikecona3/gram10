import SwiftUI

struct RootTabView: View {
    enum Tab: CaseIterable {
        case feed, popular, share, news, profile

        var title: String {
            switch self {
            case .feed: return "Feed"
            case .popular: return "Popular"
            case .share: return "Share"
            case .news: return "News"
            case .profile: return "Profile"
            }
        }

        var icon: String {
            switch self {
            case .feed: return "house.fill"
            case .popular: return "safari"
            case .share: return "camera.fill"
            case .news: return "bubble.left.fill"
            case .profile: return "person.crop.square"
            }
        }
    }

    @State private var selection: Tab = .feed

    var body: some View {
        ZStack {
            switch selection {
            case .feed: FeedView()
            case .popular: PopularView()
            case .share: NewPostFlow()
            case .news: NewsView()
            case .profile: ProfileView()
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            InstagramTabBar(
                selection: $selection,
                items: Tab.allCases.map { .init(tab: $0, icon: $0.icon, isAction: $0 == .share) }
            )
        }
    }
}

private struct PopularView: View {
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "heart.fill")
                .font(.system(size: 40))
                .foregroundStyle(.secondary)
            Text("Popular photos will appear here.")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(white: 0.94).ignoresSafeArea())
        .safeAreaInset(edge: .top, spacing: 0) {
            InstagramNavBar(title: "Popular")
        }
    }
}

private struct NewsView: View {
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "bubble.left.and.bubble.right.fill")
                .font(.system(size: 40))
                .foregroundStyle(.secondary)
            Text("Activity from your friends will appear here.")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(white: 0.94).ignoresSafeArea())
        .safeAreaInset(edge: .top, spacing: 0) {
            InstagramNavBar(title: "News")
        }
    }
}

private struct ProfileView: View {
    @EnvironmentObject var store: PostStore
    @EnvironmentObject var instagramAuth: InstagramAuthManager
    @State private var isImporting = false
    private let columns = [GridItem(.flexible(), spacing: 3), GridItem(.flexible(), spacing: 3), GridItem(.flexible(), spacing: 3)]

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                HStack(spacing: 16) {
                    VintageCameraBadge(size: 64)
                    HStack(spacing: 0) {
                        statColumn(value: "\(store.feed.count)", label: "photos")
                        statColumn(value: "0", label: "followers")
                        statColumn(value: "0", label: "following")
                    }
                }
                .padding(.horizontal, 14)
                .padding(.top, 14)

                actionSection
                    .padding(.horizontal, 14)
                    .padding(.top, 12)

                VStack(alignment: .leading, spacing: 2) {
                    Text(instagramAuth.isConnected ? (instagramAuth.profile?.username ?? "you") : "you")
                        .font(.system(.subheadline, design: .rounded)).bold()
                    Text(instagramAuth.isConnected
                         ? "Connected · \(instagramAuth.profile?.account_type ?? "Instagram")"
                         : "\(store.feed.count) photo\(store.feed.count == 1 ? "" : "s") shared here.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 14)
                .padding(.top, 12)

                HStack {
                    Image(systemName: "square.grid.3x3.fill")
                        .foregroundStyle(Skeuo.instagramBlue)
                    Spacer()
                    Image(systemName: "list.bullet")
                        .foregroundStyle(.secondary)
                    Spacer()
                    HStack(spacing: 4) {
                        Image(systemName: "mappin.and.ellipse")
                        Text("Photo Map")
                        Image(systemName: "chevron.right")
                    }
                    .foregroundStyle(.secondary)
                }
                .font(.system(size: 16))
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
                .overlay(Rectangle().fill(Color(white: 0.85)).frame(height: 1), alignment: .top)
                .overlay(Rectangle().fill(Color(white: 0.85)).frame(height: 1), alignment: .bottom)
                .padding(.top, 14)

                LazyVGrid(columns: columns, spacing: 3) {
                    ForEach(store.feed) { post in
                        Image(uiImage: post.image)
                            .resizable()
                            .scaledToFill()
                            .frame(height: 120)
                            .clipped()
                            .stitchedBorder(cornerRadius: 0)
                    }
                }
                .padding(.top, 3)
            }
        }
        .background(Color(white: 0.94).ignoresSafeArea())
        .safeAreaInset(edge: .top, spacing: 0) {
            InstagramNavBar(title: "Profile") {
                Image(systemName: "square.and.arrow.up")
                    .foregroundStyle(.white)
            }
        }
    }

    private func statColumn(value: String, label: String) -> some View {
        VStack(spacing: 2) {
            Text(value).font(.system(.subheadline, design: .rounded)).bold()
            Text(label).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    @ViewBuilder
    private var actionSection: some View {
        if instagramAuth.isConnected {
            Button {
                Task {
                    isImporting = true
                    let media = await instagramAuth.fetchMedia()
                    await importAsPosts(media)
                    isImporting = false
                }
            } label: {
                if isImporting {
                    ProgressView().tint(.white).frame(maxWidth: .infinity)
                } else {
                    Text("Import My Photos").frame(maxWidth: .infinity)
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(Skeuo.instagramBlue)
            .disabled(isImporting)

            Button("Disconnect", role: .destructive) { instagramAuth.disconnect() }
                .font(.caption)
        } else {
            Button {
                instagramAuth.connect()
            } label: {
                Text("Connect Instagram").frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(Skeuo.instagramBlue)

            if instagramAuth.isWorking {
                ProgressView("Signing in...")
            }
            if let error = instagramAuth.lastError {
                Text(error)
                    .font(.caption2)
                    .foregroundStyle(.red)
                    .multilineTextAlignment(.center)
            }
        }
    }

    /// Downloads each real Instagram photo, square-crops it, and adds it to
    /// the in-app feed. Skips videos/carousels — this clone only does photos.
    private func importAsPosts(_ media: [IGMediaItem]) async {
        let formatter = ISO8601DateFormatter()
        for item in media where item.media_type == "IMAGE" {
            guard let urlString = item.media_url, let url = URL(string: urlString) else { continue }
            guard let downloaded = try? await ImageProcessing.download(url) else { continue }
            let square = ImageProcessing.squareCropped(downloaded)
            let date = formatter.date(from: item.timestamp) ?? Date()
            store.addPost(
                image: square,
                filter: .normal,
                caption: item.caption ?? "",
                username: instagramAuth.profile?.username ?? "you",
                createdAt: date
            )
        }
    }
}
