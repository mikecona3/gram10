import Combine
import SwiftUI
import UIKit

/// Lets a SwiftUI button trigger a shutter press on an embedded CameraCapture
/// view, since UIImagePickerController's capture method isn't otherwise
/// reachable from outside its own (hidden, in our case) camera controls.
final class CameraCaptureController: ObservableObject {
    fileprivate weak var picker: UIImagePickerController?

    func capture() {
        picker?.takePicture()
    }
}

/// Wraps UIImagePickerController's camera source as an inline live
/// viewfinder (not a modal sheet) with the stock shutter/controls hidden,
/// so SwiftUI can draw its own capture and gallery buttons on top.
struct CameraCapture: UIViewControllerRepresentable {
    var controller: CameraCaptureController
    var onCapture: (UIImage) -> Void

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.showsCameraControls = false
        picker.delegate = context.coordinator
        controller.picker = picker
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onCapture: onCapture)
    }

    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let onCapture: (UIImage) -> Void

        init(onCapture: @escaping (UIImage) -> Void) {
            self.onCapture = onCapture
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let image = info[.originalImage] as? UIImage {
                onCapture(image)
            }
        }
    }
}
