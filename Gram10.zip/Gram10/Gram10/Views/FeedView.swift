import SwiftUI

struct FeedView: View {
    @EnvironmentObject var store: PostStore

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 0) {
                    Color.clear.frame(height: 0).id("top")
                    if store.feed.isEmpty {
                        emptyState
                    }
                    ForEach(store.feed) { post in
                        PostRow(post: post)
                    }
                }
            }
            .background(Color.white.ignoresSafeArea())
            .safeAreaInset(edge: .top, spacing: 0) {
                InstagramNavBar(title: "Instagram") {
                    Button {
                        withAnimation { proxy.scrollTo("top", anchor: .top) }
                    } label: {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .foregroundStyle(.white)
                    }
                }
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 8) {
            VintageCameraBadge(size: 48)
            Text("No photos yet")
                .foregroundStyle(.secondary)
            Text("Tap the camera tab to post your first one")
                .font(.caption)
                .foregroundStyle(.tertiary)
        }
        .padding(.top, 80)
        .frame(maxWidth: .infinity)
    }
}

private struct PostRow: View {
    let post: Post

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 8) {
                RoundedRectangle(cornerRadius: 5)
                    .fill(RadialGradient(colors: [Skeuo.woodLight, Skeuo.woodDark], center: .topLeading, startRadius: 1, endRadius: 30))
                    .frame(width: 32, height: 32)
                    .overlay(RoundedRectangle(cornerRadius: 5).stroke(.black.opacity(0.3), lineWidth: 1))
                    .overlay(Text(String(post.username.prefix(1)).uppercased()).font(.caption).bold().foregroundStyle(.white))
                Text(post.username)
                    .font(.system(.subheadline, design: .rounded)).bold()
                    .foregroundStyle(.black)
                Spacer()
                HStack(spacing: 4) {
                    Circle().frame(width: 4, height: 4)
                    Text(post.timeAgo)
                }
                .font(.caption)
                .foregroundStyle(Color(white: 0.6))
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)

            Image(uiImage: post.image)
                .resizable()
                .scaledToFit()
                .aspectRatio(1, contentMode: .fit)
                .frame(maxWidth: .infinity)
                .vintagePhotoBorder()

            if !post.caption.isEmpty {
                Text(post.caption)
                    .font(.system(.footnote, design: .serif))
                    .foregroundStyle(.black.opacity(0.75))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 10)
                    .padding(.top, 8)
            }

            HStack(spacing: 18) {
                Image(systemName: "heart")
                Image(systemName: "bubble.right")
                Image(systemName: "paperplane")
                Spacer()
                Text(post.filter.rawValue)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .italic()
            }
            .font(.system(size: 19))
            .foregroundStyle(.black.opacity(0.8))
            .padding(.horizontal, 12)
            .padding(.top, 8)
            .padding(.bottom, 10)
        }
        .background(Color.white)
        .overlay(alignment: .bottom) {
            Rectangle().fill(Color(white: 0.85)).frame(height: 1)
        }
    }
}
