import SwiftUI
import PhotosUI

struct NewPostFlow: View {
    @EnvironmentObject var store: PostStore
    @EnvironmentObject var instagramAuth: InstagramAuthManager

    @State private var pickerItem: PhotosPickerItem?
    @State private var originalSquare: UIImage?
    @State private var showGalleryPicker = false
    @StateObject private var cameraController = CameraCaptureController()
    @State private var selectedFilter: FilterType = .normal
    @State private var caption = ""
    @State private var alsoPostToInstagram = false
    @State private var isPublishing = false
    @State private var publishError: String?
    @State private var publishedSuccessfully = false

    var body: some View {
        ZStack {
            LeatherBackground().ignoresSafeArea()

            Group {
                if let original = originalSquare {
                    filterAndCaptionStep(original: original)
                } else {
                    pickStep
                }
            }
        }
        .safeAreaInset(edge: .top, spacing: 0) {
            InstagramNavBar(title: originalSquare == nil ? "New Photo" : "Edit") {
                if originalSquare != nil {
                    Button("Cancel") { reset() }
                        .font(.system(size: 14))
                        .foregroundStyle(Skeuo.stitchCream)
                }
            }
        }
    }

    // MARK: - Step 1: live camera viewfinder, like the old camera-app splash

    private var pickStep: some View {
        ZStack {
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                CameraCapture(controller: cameraController) { image in
                    originalSquare = ImageProcessing.squareCropped(image)
                }
                .ignoresSafeArea()

                VStack {
                    Spacer()
                    HStack {
                        Button {
                            showGalleryPicker = true
                        } label: {
                            Image(systemName: "photo.on.rectangle")
                                .font(.system(size: 22))
                                .foregroundStyle(.white)
                                .frame(width: 54, height: 54)
                                .background(Circle().fill(Color.black.opacity(0.35)))
                                .overlay(Circle().strokeBorder(Color.white.opacity(0.7), lineWidth: 2))
                        }
                        .padding(.leading, 28)

                        Spacer()

                        Button {
                            cameraController.capture()
                        } label: {
                            ZStack {
                                Circle().fill(Color.white).frame(width: 70, height: 70)
                                Circle().strokeBorder(Color.white.opacity(0.9), lineWidth: 4).frame(width: 82, height: 82)
                            }
                        }

                        Spacer()

                        // Balances the gallery button so the shutter stays centered.
                        Color.clear.frame(width: 54, height: 54).padding(.trailing, 28)
                    }
                    .padding(.bottom, 30)
                }
            } else {
                VStack(spacing: 26) {
                    Spacer()
                    VintageCameraBadge(size: 90)
                        .shadow(color: .black.opacity(0.6), radius: 8, y: 4)
                    Text("Camera not available on this device")
                        .font(.system(.footnote, design: .serif))
                        .foregroundStyle(Skeuo.stitchCream.opacity(0.85))
                    Button {
                        showGalleryPicker = true
                    } label: {
                        Text("Choose from your library")
                            .font(.system(.footnote, design: .serif))
                            .underline()
                            .foregroundStyle(Skeuo.stitchCream)
                    }
                    Spacer()
                    Spacer()
                }
            }
        }
        .photosPicker(isPresented: $showGalleryPicker, selection: $pickerItem, matching: .images)
        .onChange(of: pickerItem) { newItem in
            Task {
                guard let newItem, let data = try? await newItem.loadTransferable(type: Data.self),
                      let image = UIImage(data: data) else { return }
                originalSquare = ImageProcessing.squareCropped(image)
            }
        }
    }

    // MARK: - Step 2: filter + caption

    private func filterAndCaptionStep(original: UIImage) -> some View {
        VStack(spacing: 0) {
            Image(uiImage: ImageProcessing.filtered(original, with: selectedFilter))
                .resizable()
                .scaledToFit()
                .aspectRatio(1, contentMode: .fit)
                .frame(maxWidth: .infinity)
                .polaroidFrame()
                .padding(14)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(FilterType.allCases) { filter in
                        FilterThumb(
                            image: original,
                            filter: filter,
                            isSelected: filter == selectedFilter
                        )
                        .onTapGesture { selectedFilter = filter }
                    }
                }
                .padding(12)
            }
            .background(Color.black.opacity(0.25))

            TextField("", text: $caption, prompt: Text("Write a caption...").foregroundStyle(.white.opacity(0.5)))
                .foregroundStyle(.white)
                .padding(10)
                .background(Color.black.opacity(0.3))
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .padding(12)

            if instagramAuth.isConnected {
                Toggle(isOn: $alsoPostToInstagram) {
                    Text("Also post to my real Instagram")
                        .font(.footnote)
                        .foregroundStyle(.white)
                }
                .tint(.green)
                .padding(.horizontal, 12)
                .padding(.bottom, 8)
            }

            if let publishError {
                Text(publishError)
                    .font(.caption2)
                    .foregroundStyle(.red)
                    .padding(.horizontal, 12)
            }

            Button {
                Task { await post(original: original) }
            } label: {
                if isPublishing {
                    ProgressView().tint(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                } else {
                    Text("Share Photo")
                        .font(.system(.headline, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                }
            }
            .disabled(isPublishing)
            .foregroundStyle(.white)
            .background(
                LinearGradient(colors: [Color.green.opacity(0.9), Color.green.opacity(0.6)], startPoint: .top, endPoint: .bottom)
            )
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(.black.opacity(0.4), lineWidth: 1))
            .padding(.horizontal, 12)
            .padding(.bottom, 16)

            Spacer(minLength: 0)
        }
        .alert("Posted to Instagram", isPresented: $publishedSuccessfully) {
            Button("OK") {}
        } message: {
            Text("Your photo is live on your real account.")
        }
    }

    private func post(original: UIImage) async {
        let finalImage = ImageProcessing.filtered(original, with: selectedFilter)

        if alsoPostToInstagram {
            isPublishing = true
            publishError = nil
            do {
                _ = try await instagramAuth.publishToInstagram(image: finalImage, caption: caption)
                publishedSuccessfully = true
            } catch {
                publishError = "Couldn't post to Instagram: \(error.localizedDescription)"
                isPublishing = false
                return // keep the sheet open so they can retry without losing the photo
            }
            isPublishing = false
        }

        store.addPost(image: finalImage, filter: selectedFilter, caption: caption)
        reset()
    }

    private func reset() {
        pickerItem = nil
        originalSquare = nil
        selectedFilter = .normal
        caption = ""
        alsoPostToInstagram = false
        publishError = nil
    }
}

private struct FilterThumb: View {
    let image: UIImage
    let filter: FilterType
    let isSelected: Bool

    var body: some View {
        VStack(spacing: 4) {
            Image(uiImage: ImageProcessing.filtered(image, with: filter))
                .resizable()
                .scaledToFill()
                .frame(width: 62, height: 62)
                .clipShape(RoundedRectangle(cornerRadius: 4))
                .overlay(
                    RoundedRectangle(cornerRadius: 4)
                        .stroke(isSelected ? Skeuo.stitchCream : Color.black.opacity(0.4), lineWidth: isSelected ? 2.5 : 1)
                )
                .shadow(color: .black.opacity(0.5), radius: 3, y: 2)
            Text(filter.rawValue)
                .font(.caption2)
                .foregroundStyle(isSelected ? .white : .white.opacity(0.6))
        }
    }
}
