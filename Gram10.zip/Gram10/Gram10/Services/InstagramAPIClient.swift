import Foundation

enum InstagramAPIError: Error, LocalizedError {
    case badResponse(Int, String)
    var errorDescription: String? {
        switch self {
        case .badResponse(let code, let body): return "HTTP \(code): \(body)"
        }
    }
}

enum InstagramAPIClient {
    /// POST https://api.instagram.com/oauth/access_token — code -> short-lived token (1hr)
    static func exchangeCodeForToken(code: String) async throws -> IGShortLivedToken {
        var request = URLRequest(url: URL(string: "https://api.instagram.com/oauth/access_token")!)
        request.httpMethod = "POST"
        let params = [
            "client_id": InstagramConfig.appID,
            "client_secret": InstagramConfig.appSecret,
            "grant_type": "authorization_code",
            "redirect_uri": InstagramConfig.redirectURI,
            "code": code,
        ]
        request.httpBody = params
            .map { "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")" }
            .joined(separator: "&")
            .data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        return try await send(request)
    }

    /// GET https://graph.instagram.com/access_token — short-lived -> long-lived token (60 days)
    static func exchangeForLongLivedToken(shortLivedToken: String) async throws -> IGLongLivedToken {
        var components = URLComponents(string: "https://graph.instagram.com/access_token")!
        components.queryItems = [
            URLQueryItem(name: "grant_type", value: "ig_exchange_token"),
            URLQueryItem(name: "client_secret", value: InstagramConfig.appSecret),
            URLQueryItem(name: "access_token", value: shortLivedToken),
        ]
        let request = URLRequest(url: components.url!)
        return try await send(request)
    }

    /// GET https://graph.instagram.com/me — basic profile
    static func fetchProfile(accessToken: String) async throws -> IGProfile {
        var components = URLComponents(string: "https://graph.instagram.com/me")!
        components.queryItems = [
            URLQueryItem(name: "fields", value: "id,username,account_type"),
            URLQueryItem(name: "access_token", value: accessToken),
        ]
        let request = URLRequest(url: components.url!)
        return try await send(request)
    }

    /// GET https://graph.instagram.com/me/media — the account's own published posts
    static func fetchMedia(accessToken: String, limit: Int = 25) async throws -> [IGMediaItem] {
        var components = URLComponents(string: "https://graph.instagram.com/me/media")!
        components.queryItems = [
            URLQueryItem(name: "fields", value: "id,caption,media_type,media_url,timestamp,permalink"),
            URLQueryItem(name: "limit", value: String(limit)),
            URLQueryItem(name: "access_token", value: accessToken),
        ]
        let request = URLRequest(url: components.url!)
        let response: IGMediaResponse = try await send(request)
        return response.data
    }

    // MARK: - Publishing (container -> poll -> publish)

    /// Step 1: tell Instagram where the image lives. It downloads it from
    /// `imageURL` itself — this only works if that URL is public.
    static func createMediaContainer(igUserID: String, imageURL: URL, caption: String, accessToken: String) async throws -> String {
        var components = URLComponents(string: "https://graph.facebook.com/v21.0/\(igUserID)/media")!
        components.queryItems = [
            URLQueryItem(name: "image_url", value: imageURL.absoluteString),
            URLQueryItem(name: "caption", value: caption),
            URLQueryItem(name: "access_token", value: accessToken),
        ]
        var request = URLRequest(url: components.url!)
        request.httpMethod = "POST"
        let result: IGContainerCreated = try await send(request)
        return result.id
    }

    /// Step 2: poll until Instagram has finished downloading/validating the image.
    static func waitForContainerReady(containerID: String, accessToken: String, maxAttempts: Int = 20) async throws {
        for _ in 0..<maxAttempts {
            var components = URLComponents(string: "https://graph.facebook.com/v21.0/\(containerID)")!
            components.queryItems = [
                URLQueryItem(name: "fields", value: "status_code"),
                URLQueryItem(name: "access_token", value: accessToken),
            ]
            let status: IGContainerStatus = try await send(URLRequest(url: components.url!))
            switch status.status_code {
            case "FINISHED":
                return
            case "ERROR", "EXPIRED":
                throw InstagramAPIError.badResponse(0, "Container status: \(status.status_code)")
            default:
                try await Task.sleep(nanoseconds: 2_000_000_000)
            }
        }
        throw InstagramAPIError.badResponse(0, "Timed out waiting for Instagram to process the image.")
    }

    /// Step 3: actually publish the finished container to the feed.
    static func publishContainer(igUserID: String, containerID: String, accessToken: String) async throws -> String {
        var components = URLComponents(string: "https://graph.facebook.com/v21.0/\(igUserID)/media_publish")!
        components.queryItems = [
            URLQueryItem(name: "creation_id", value: containerID),
            URLQueryItem(name: "access_token", value: accessToken),
        ]
        var request = URLRequest(url: components.url!)
        request.httpMethod = "POST"
        let result: IGPublishedMedia = try await send(request)
        return result.id
    }

    // MARK: - Shared request/decode helper

    private static func send<T: Decodable>(_ request: URLRequest) async throws -> T {
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let code = (response as? HTTPURLResponse)?.statusCode ?? -1
            let body = String(data: data, encoding: .utf8) ?? ""
            throw InstagramAPIError.badResponse(code, body)
        }
        return try JSONDecoder().decode(T.self, from: data)
    }
}
