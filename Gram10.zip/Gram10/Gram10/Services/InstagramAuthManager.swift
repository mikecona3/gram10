import AuthenticationServices
import Combine
import SwiftUI

@MainActor
final class InstagramAuthManager: NSObject, ObservableObject {
    @Published var isConnected = false
    @Published var profile: IGProfile?
    @Published var lastError: String?
    @Published var isWorking = false

    /// Kept in memory only for this demo. For anything beyond your own
    /// personal build, move this into the Keychain instead of UserDefaults.
    private var accessToken: String? {
        get { UserDefaults.standard.string(forKey: "ig_access_token") }
        set { UserDefaults.standard.set(newValue, forKey: "ig_access_token") }
    }

    private var session: ASWebAuthenticationSession?

    override init() {
        super.init()
        if accessToken != nil {
            isConnected = true
            Task { await refreshProfile() }
        }
    }

    // MARK: - Step 1: kick off the browser-based login

    func connect() {
        lastError = nil
        var components = URLComponents(string: "https://www.instagram.com/oauth/authorize")!
        components.queryItems = [
            URLQueryItem(name: "client_id", value: InstagramConfig.appID),
            URLQueryItem(name: "redirect_uri", value: InstagramConfig.redirectURI),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "scope", value: InstagramConfig.scope),
        ]

        guard let url = components.url else { return }

        let session = ASWebAuthenticationSession(
            url: url,
            callbackURLScheme: InstagramConfig.callbackScheme
        ) { [weak self] callbackURL, error in
            Task { @MainActor in
                await self?.handleCallback(callbackURL: callbackURL, error: error)
            }
        }
        session.presentationContextProvider = self
        session.prefersEphemeralWebBrowserSession = true
        self.session = session
        session.start()
    }

    func disconnect() {
        accessToken = nil
        isConnected = false
        profile = nil
    }

    // MARK: - Step 2: handle the redirect, exchange the code for tokens

    private func handleCallback(callbackURL: URL?, error: Error?) async {
        if let error {
            // .canceledLogin happens when the person just dismisses the sheet — not a real error.
            if (error as? ASWebAuthenticationSessionError)?.code != .canceledLogin {
                lastError = error.localizedDescription
            }
            return
        }
        guard let callbackURL,
              let code = URLComponents(url: callbackURL, resolvingAgainstBaseURL: false)?
                .queryItems?.first(where: { $0.name == "code" })?.value
        else {
            lastError = "Didn't get an authorization code back."
            return
        }

        isWorking = true
        defer { isWorking = false }

        do {
            let shortLived = try await InstagramAPIClient.exchangeCodeForToken(code: code)
            let longLived = try await InstagramAPIClient.exchangeForLongLivedToken(shortLivedToken: shortLived.access_token)
            accessToken = longLived.access_token
            isConnected = true
            await refreshProfile()
        } catch {
            lastError = "Login succeeded but the token exchange failed: \(error.localizedDescription)"
        }
    }

    // MARK: - Profile + media

    func refreshProfile() async {
        guard let token = accessToken else { return }
        do {
            profile = try await InstagramAPIClient.fetchProfile(accessToken: token)
        } catch {
            lastError = "Couldn't load your profile: \(error.localizedDescription)"
        }
    }

    func fetchMedia() async -> [IGMediaItem] {
        guard let token = accessToken else { return [] }
        do {
            return try await InstagramAPIClient.fetchMedia(accessToken: token)
        } catch {
            lastError = "Couldn't load your posts: \(error.localizedDescription)"
            return []
        }
    }

    // MARK: - Publishing a photo taken/filtered in the app

    enum PublishError: Error, LocalizedError {
        case notConnected
        var errorDescription: String? {
            "Connect your Instagram account first."
        }
    }

    /// Uploads the image to Firebase Storage for a public URL, then runs the
    /// container -> poll -> publish flow. Returns the published post's ID.
    func publishToInstagram(image: UIImage, caption: String) async throws -> String {
        guard let token = accessToken, let igUserID = profile?.id else {
            throw PublishError.notConnected
        }
        let publicURL = try await FirebaseUploader.uploadPublicImage(image)
        let containerID = try await InstagramAPIClient.createMediaContainer(
            igUserID: igUserID, imageURL: publicURL, caption: caption, accessToken: token
        )
        try await InstagramAPIClient.waitForContainerReady(containerID: containerID, accessToken: token)
        return try await InstagramAPIClient.publishContainer(igUserID: igUserID, containerID: containerID, accessToken: token)
    }
}

extension InstagramAuthManager: ASWebAuthenticationPresentationContextProviding {
    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        UIApplication.shared.connectedScenes
            .compactMap { ($0 as? UIWindowScene)?.keyWindow }
            .first ?? ASPresentationAnchor()
    }
}
