import FirebaseAuth
import FirebaseCore
import FirebaseStorage
import UIKit

enum FirebaseUploadError: Error, LocalizedError {
    case couldNotEncodeImage
    case firebaseNotConfigured
    var errorDescription: String? {
        switch self {
        case .couldNotEncodeImage:
            return "Couldn't prepare the image for upload."
        case .firebaseNotConfigured:
            return "Firebase isn't set up yet — add GoogleService-Info.plist and the Storage/Auth setup from the README before posting to real Instagram."
        }
    }
}

enum FirebaseUploader {
    /// Uploads a JPEG to Storage under /posts/{uuid}.jpg and returns its public
    /// download URL — the URL Instagram's servers will fetch the image from.
    /// Signs in anonymously first so writes require *some* auth even though
    /// reads are public (see Storage rules in the README).
    static func uploadPublicImage(_ image: UIImage) async throws -> URL {
        guard FirebaseApp.app() != nil else {
            throw FirebaseUploadError.firebaseNotConfigured
        }

        try await ensureSignedIn()

        guard let data = image.jpegData(compressionQuality: 0.9) else {
            throw FirebaseUploadError.couldNotEncodeImage
        }

        let path = "posts/\(UUID().uuidString).jpg"
        let ref = Storage.storage().reference().child(path)
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpeg"

        _ = try await ref.putDataAsync(data, metadata: metadata)
        return try await ref.downloadURL()
    }

    private static func ensureSignedIn() async throws {
        if Auth.auth().currentUser != nil { return }
        _ = try await Auth.auth().signInAnonymously()
    }
}
