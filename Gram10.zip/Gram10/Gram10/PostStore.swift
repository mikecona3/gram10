import SwiftUI
public import Combine

@MainActor
final class PostStore: ObservableObject {
    @Published private(set) var posts: [Post] = []

    /// Newest first — straight reverse-chronological, exactly what the 2010 feed did.
    var feed: [Post] {
        posts.sorted { $0.createdAt > $1.createdAt }
    }

    func addPost(image: UIImage, filter: FilterType, caption: String, username: String = "you", createdAt: Date = Date()) {
        let post = Post(username: username, image: image, filter: filter, caption: caption, createdAt: createdAt)
        posts.append(post)
    }

    init() {
        SeedData.populateIfEmpty(self)
    }
}
